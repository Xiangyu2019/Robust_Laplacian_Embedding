import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans


def KCluster(k, data):
    kmeans = KMeans(n_clusters=k)
    y_kmeans = kmeans.fit_predict(data)
    print(y_kmeans)
    return y_kmeans


def create_graph():
    G = nx.Graph()
    G.add_nodes_from(['a', 'b', 'c', 'd', 'e', 'f'])
    G.add_edge('a', 'b')
    G.add_edge('a', 'e')
    G.add_edge('a', 'f')
    G.add_edge('b', 'c')
    G.add_edge('b', 'd')
    # G.add_edge('a', 'c')
    return G


def print_results(embedding, iterations, objective_list, G, clusters):
    nx.draw(G)
    plt.savefig("simple_graph")
    plt.show()
    plt.scatter(embedding[:, 0], embedding[:, 1], c=clusters, cmap='rainbow')
    plt.savefig("simple_graph_embedding.png")  # save as png
    plt.show()
    plt.plot(range(0, iterations, 10), objective_list)
    plt.savefig("simple_graph_objective.png")
    plt.show()


def gradient_x(w, curr_embedding, row, curr_lambda, p, r):
    total_sum = 0
    for i in range(len(w)):
        outer_sum = np.zeros(r)
        for j in range(r):
            inner_sum = np.zeros(r)
            for n in range(len(w)):
                inner_sum = inner_sum + (p * (np.linalg.norm(curr_embedding[i] - curr_embedding[n], p) ** (p - 2))
                                         * (curr_embedding[i] - curr_embedding[n]))
            outer_sum = outer_sum + (inner_sum * w[i][j])
    total_sum = outer_sum + (2 * curr_lambda * curr_embedding[row])
    return total_sum


def gradient_l(curr_embedding):
    return (np.linalg.norm(curr_embedding) ** 2) - 1


def iterate_l(curr_lambda, curr_embedding, mu):
    L = gradient_l((curr_embedding))
    return curr_lambda - ((1 / mu) * L)


def iterate_x(w, curr_embedding, curr_lambda, mu, p, r):
    for row in range(len(curr_embedding)):
        L = gradient_x(w, curr_embedding, row, curr_lambda, p, r)
        curr_embedding[row] = curr_embedding[row] - ((1 / mu) * L)
    # print(curr_embedding[row])
    return curr_embedding


# Creates nXn similarity matrix of the graph G
def create_w(G, n):
    w = np.zeros((n, n))
    lengths = dict(nx.shortest_path_length(G))
    ii = -1
    jj = -1
    for i in G.nodes:
        ii = ii + 1
        jj = -1
        for j in G.nodes:
            jj = jj + 1
            w[ii][jj] = lengths[i][j]
    return w


def objective(w, p, r, embedding, l):
    total_sum = 0
    for i in range(len(w)):
        for j in range(r):
            total_sum = total_sum + (w[i][j] * np.linalg.norm(embedding[i] - embedding[j], p) ** p)
    return total_sum


def l_embedding(G, k, l_mu, x_mu, p, r, curr_lambda):
    num_nodes = len(G)
    embedding = np.random.rand(num_nodes, r)
    w = create_w(G, num_nodes)

    objective_list = []

    for i in range(k):
        embedding = iterate_x(w, embedding, curr_lambda, x_mu, p, r)
        curr_lambda = iterate_l(curr_lambda, embedding, l_mu)
        # print(embedding)
        if i % 10 == 0:
            objective_list.append(objective(w, p, r, embedding, curr_lambda))
        if i % 1000 == 0:
            print(i)
            # print(embedding)
            print("Objective: ", objective(w, p, r, embedding, curr_lambda))
            print(f"Lambda: {curr_lambda}")
    return embedding, objective_list


# Initial conditions
iterations = 10000
p_value = 2
initial_lambda = 1
dimensions = 2
l_mu = 10000
x_mu = 10000
G = create_graph()

# l_embedding(Graph, Iterations, lambda_mu, x_mu, P, dimensions)
embedding, objective_list = l_embedding(G, iterations, l_mu, x_mu, p_value, dimensions, initial_lambda)
clusters = KCluster(2, embedding)
print_results(embedding, iterations, objective_list, G, clusters)
