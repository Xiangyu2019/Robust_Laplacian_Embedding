import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
import math


class Autoencoder_Linear(nn.Module):
    def __init__(self, shape, m):
        self.shape = shape[1]
        self.m = m
        super().__init__()
        self.shape_1 = 2 * math.ceil(shape[1]/2)
        self.shape_2 = math.ceil(self.shape_1/2)
        self.encoder = nn.Sequential(
            nn.Linear(self.shape, self.shape_1),  # (N, shape) -> (N, shape/2)
            nn.ReLU(),
            nn.Linear(self.shape_1, self.shape_2),  # (N, shape) -> (N, shape/2)
            nn.ReLU(),
            nn.Linear(self.shape_2, m),
        )

        self.decoder = nn.Sequential(
            nn.Linear(m, self.shape_2),
            nn.ReLU(),
            nn.Linear(self.shape_2, self.shape_1),
            nn.ReLU(),
            nn.Linear(self.shape_1, self.shape),
            nn.Sigmoid(),
        )

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return encoded,decoded