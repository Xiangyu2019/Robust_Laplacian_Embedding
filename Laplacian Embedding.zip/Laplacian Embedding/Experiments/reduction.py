import numpy as np
import torch
from torch.utils.data import TensorDataset
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torchvision import datasets, transforms
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.decomposition import PCA
from AE import Autoencoder_Linear
from RBM import RBM
import math
from sklearn import preprocessing
from sklearn.cluster import SpectralClustering
from sklearn.manifold import LocallyLinearEmbedding
from LPEmbedding import objective

class reduction:
    def __init__(self,X_c, Y, n=4):
        self.X_c = X_c
        self.Y = Y
        self.n = n

    def X_F(self):
        if len(self.X_c.shape) == 2:
            return self.X_c
        n_class = self.X_c.shape[0]
        X = self.X_c[0]
        for i in range(n_class-1):
            X = np.concatenate((X,self.X_c[i+1]))
        X = X.astype(np.float32)
        X = preprocessing.StandardScaler().fit_transform(X)

        return X

    def sk_lda(self):
        lda = LinearDiscriminantAnalysis(n_components=self.n)
        data = self.X_F()
        data = data.astype(np.object)
        print(self.Y)
        X_new = lda.fit_transform(X=data,y=self.Y)
        return X_new.T,self.Y

    def sk_pca(self):
        pca = PCA(n_components=self.n)
        data = self.X_F()
        X_new = pca.fit_transform(data,self.Y)
        return X_new.T,self.Y

    def py_ae(self):
        transform = transforms.ToTensor()
        data = self.X_F()
        print(f'data: {data.shape}')
        data = torch.Tensor(data)
        label = torch.Tensor(self.Y)
        train_data = TensorDataset(data, label)
        # train_data = []
        batch = 64 #math.ceil(data.shape[0]/3)
        # for i in range(len(self.Y)):
        #     # train_data.append([torch.from_numpy(data[i]), torch.from_numpy(self.Y[i])])
        #     train_data.append([data[i], self.Y[i]])
        # train_data = np.array(train_data)
        data_loader = torch.utils.data.DataLoader(train_data,batch_size=batch,shuffle=True)
        model = Autoencoder_Linear(shape= data.shape, m=self.n)
        criterion = nn.MSELoss()
        optimizer = torch.optim.Adam(model.parameters(),lr=1e-3,weight_decay=1e-5)
        num_epochs = 20
        output_data = []
        output_label = []
        for epoch in range(num_epochs):
            for k,(sample, label) in enumerate(data_loader):
                encode,recon = model(sample)
                loss = criterion(recon, sample)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                if epoch == (num_epochs - 1):
                    output_data.extend(encode.detach().numpy())
                    output_label.extend(label.detach().numpy())
            print(f'epoch{epoch}_loss={loss}')
        X_new = np.array(output_data)
        Y_label = np.array(output_label)

        return X_new.T, Y_label

    def py_rbm(self):
        transform = transforms.ToTensor()
        data = self.X_F()
        data = torch.Tensor(data)
        label = torch.Tensor(self.Y)
        train_data = TensorDataset(data, label)
        batch = 64
        data_loader = torch.utils.data.DataLoader(train_data, batch_size=batch, shuffle=True)
        model = RBM(n_vis=data.shape[1], n_hid=self.n, k=1)
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
        num_epochs = 100
        output_data = []
        output_label = []
        for epoch in range(num_epochs):
            for k,(sample, label) in enumerate(data_loader):
                encode,recon,h = model(sample)
                loss = model.free_energy(encode) - model.free_energy(recon)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                if epoch == (num_epochs -1):
                    output_data.extend(h.detach().numpy())
                    output_label.extend(label.detach().numpy())
        X_new = np.array(output_data)
        Y_label = np.array(output_label)
        return X_new.T, Y_label


    def NCut(self, affinity):

        clustering = SpectralClustering(n_clusters=len(np.unique(self.Y)), affinity="precomputed").fit(affinity)
        return clustering.labels_, self.Y

    def LLE(self):
        embedding = LocallyLinearEmbedding(n_components=2)
        x_transformed = embedding.fit_transform(self.X_F())
        return x_transformed,self.Y

    def PNLE(self, w, p, mu):
        #initialize
        x = np.random.rand(w.shape[0], self.n)
        d = np.zeros(w.shape)
        W = np.zeros(w.shape)
        D = np.zeros(w.shape)
        e = np.ones(w.shape)
        l = np.ones(x.shape)

        for i in range(100):
            print(x)
            iteration = 0
            #Calculate D
            for i in range(w.shape[0]):
                for j in range(w.shape[1]):
                    if i != j:
                        d[i][j] = (p / 2) * (np.linalg.norm(x[i] - x[j]) ** 2) ** ((p - 2) / 2)

            #Use D to optimize embedding
            while iteration < 50:
                W_sum = 0
                #calculate W
                for i in range(w.shape[0]):
                    for j in range(w.shape[1]):
                        W[i][j] = w[i][j] * d[i][j]
                        W_sum += W[i][j]

                #Calculate D
                for i in range(w.shape[0]):
                    inner_sum = 0
                    for j in range(w.shape[1]):
                            inner_sum += W[i][j]
                    D[i][i] = inner_sum

                #Calculate L
                WPP = (W_sum / ((W.shape[0] ** 2))) * e
                L = D - W

                #Use L to Calculate M and solve for Y
                M = mu*x - l - L @ x
                u, s, vh = np.linalg.svd(M, full_matrices=False)
                Y = u @ vh

                #Calculate X while Y is fixed
                M = Y + (1/mu)*l - (1/mu) * L.T @ Y
                for i in range(M.shape[0]):
                    for j in range(M.shape[1]):
                        if M[i][j] > 0:
                            x[i][j] = M[i][j]
                        else:
                            x[i][j] = 0

                #update l
                l = l + mu * (Y - x)

                #update mu
                mu = p*mu
                iteration+=1
                print(f"Objective: {objective(w, 2, 2, x)}")
        return x






