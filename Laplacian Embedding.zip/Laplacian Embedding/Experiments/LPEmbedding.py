import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.metrics.cluster import normalized_mutual_info_score
from sklearn.metrics.cluster import rand_score
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.metrics.cluster import adjusted_rand_score
from numba import jit
from timeit import default_timer as timer


def cluster_acc(y_true, y_pred):
    cm = metrics.confusion_matrix(y_true, y_pred)
    _make_cost_m = lambda x:-x + np.max(x)
    indexes = linear_assignment(_make_cost_m(cm))
    indexes = np.concatenate([indexes[0][:,np.newaxis],indexes[1][:,np.newaxis]], axis=-1)
    js = [e[1] for e in sorted(indexes, key=lambda x: x[0])]
    cm2 = cm[:, js]
    acc = np.trace(cm2) / np.sum(cm2)
    return acc


def nmi_score(y_true, y_pred):
    return normalized_mutual_info_score(y_true, y_pred)


def KCluster(k, data):
    kmeans = KMeans(n_clusters=k)
    predicted_groups = kmeans.fit_predict(data)
    return predicted_groups


def knn_accuracy(k, x, y, p_value_LP):
    classifier = KNeighborsClassifier(n_neighbors=k)
    train_X, val_X, train_y, val_y = train_test_split(x, y, random_state=1)
    classifier.fit(train_X, train_y)
    val_predictions = classifier.predict(val_X)
    return accuracy_score(val_predictions, val_y, normalize=True)


def knn_OML(k, x, y, p_value_LP):
    classifier = KNeighborsClassifier(n_neighbors=k, p=p_value_LP)
    classifier.fit(x, y)
    neighbors = classifier.kneighbors(X=[x[0]], n_neighbors=10, return_distance=False)
    print(neighbors)
    return neighbors


def purity_score(y_true, y_pred):
    # compute contingency matrix
    contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
    purity = np.sum(np.amax(contingency_matrix, axis=1)) / np.sum(contingency_matrix)
    return purity


def print_results(embedding, iterations, objective_list, df, clusters, lambda_list, accuracy_list):
    plt.scatter(embedding[:, 0], embedding[:, 1], c=clusters, cmap='rainbow')
    plt.savefig("embedding.png", dpi=1000)  # save as png
    plt.clf()
    plt.plot(range(0, iterations), lambda_list)
    plt.savefig("lambda.png", dpi=1000)
    plt.clf()
    plt.plot(range(0, iterations), objective_list)
    plt.savefig("objective.png", dpi=1000)
    plt.clf()
    plt.plot(range(0, iterations), accuracy_list)
    plt.savefig("accuracy.png", dpi=1000)
    plt.clf()

    ax1 = plt.subplot()
    l1, = ax1.plot(range(0, iterations), objective_list, color='black')
    ax2 = ax1.twinx()
    l2, = ax2.plot(accuracy_list, color='red')
    ax1.set_xlabel("Iteration")
    ax1.set_ylabel("Objective", color="black")
    ax1.tick_params(axis='y', colors="black")

    ax2.tick_params(axis='y', colors="red")
    ax2.set_ylabel("Accuracy", color="red")

    plt.savefig("Test.png", dpi=1000)
@jit
def hadamard_power(row, p):
    for i in range(len(row)):
        row[i] = abs(row[i]) ** p
    return row

@jit
def gradient_x(w, curr_embedding, row, curr_lambda, p, r):
    inner_sum = np.zeros(r)
    for j in range(len(w)):
        if row != j:
            matrix_dif = curr_embedding[row] - curr_embedding[j]
            matrix_dif_2 = np.copy(matrix_dif)
            inner_sum = inner_sum + w[row][j] * (p * hadamard_power(matrix_dif, p - 2) * matrix_dif_2)
    total_sum = inner_sum - (2 * curr_lambda * curr_embedding[row])
    return total_sum

@jit
def gradient_l(curr_embedding, row):
    gradient = 1 + (np.linalg.norm(curr_embedding[row], 2) ** 2)
    return gradient

@jit
def iterate_l(curr_lambda, curr_embedding, mu, row):
    L = gradient_l(curr_embedding, row)
    curr_lambda[row] = curr_lambda[row] + ((1 / mu) * L)
    return

@jit
def iterate_x(w, curr_embedding, curr_lambda, mu, p, r, row):
    L = gradient_x(w, curr_embedding, row, curr_lambda, p, r)
    curr_embedding[row] = curr_embedding[row] - ((1 / mu) * L)
    return curr_embedding

def create_w_gaussian(df, sigma):
    print("Creating W...")
    n = len(df.index)
    w = np.zeros((n, n))
    x = df.iloc[:, range(1, len(df.columns))]
    for i in range(n):
        for j in range(n):
            w[i][j] = np.exp(-(np.linalg.norm(x.iloc[i] - x.iloc[j], 2) ** 2) / (2 * sigma ** 2))
    print("W Created")
    #np.savetxt("Resources/gaussian_w.csv", w, delimiter=',')
    return w


def create_w_gaussian_optimized(data, sigma):
    print("Creating W...")
    n = data.shape[0]
    w = np.zeros((n, n))
    x = [i[1:] for i in data]
    for i in range(n):
        print(i)
        for j in range(i+1):
            w[i][j] = np.exp(-(np.linalg.norm(x[i] - x[j], 2) ** 2) / (2 * sigma ** 2))
            w[j][i] = w[i][j]
    print("W Created")
    #np.savetxt("Resources/gaussian_w.csv", w, delimiter=',')
    return w

@jit
def objective(w, p, r, embedding):
    total_sum = 0
    for i in range(len(w)):
        for j in range(len(w)):
            total_sum = total_sum + (w[i][j] * np.linalg.norm(embedding[i] - embedding[j], p) ** p)
    return total_sum

@jit
def iterate_all(embedding, curr_lambda_list, x_mu, l_mu, p, r, w):
    for row in range(len(embedding)):
        temp_embedding = iterate_x(w, embedding, curr_lambda_list[row], x_mu, p, r, row)
        iterate_l(curr_lambda_list, embedding, l_mu, row)
        embedding = temp_embedding


def l_embedding(df, l_mu, x_mu, p, r, initial_lambda, correct_groups, gaussian_constant=10):
    #return df.values, [], 100, [], []
    num_nodes = len(df.index)
    embedding = np.random.rand(num_nodes, r)

    start = timer()
    w = create_w_gaussian_optimized(df.values, gaussian_constant)
    print(f"W took {timer()-start} Seconds to Create")

    curr_lambda_list = np.full(num_nodes, float(initial_lambda))
    objective_list = []
    accuracy_list = []
    lambda_list = []

    i = 0
    #Plot Initial Random Embedding
    #plt.scatter(embedding[:, 0], embedding[:, 1])
    #plt.savefig("embedding_random.png")
    #plt.clf()

    #Iterate X and lambda
    while True:
        i += 1
        #Update each row individually
        start = timer()
        iterate_all(embedding, curr_lambda_list, x_mu, l_mu, p, r, w)
        print(f"X took {timer() - start} Seconds to Update")

        #Keep Track of values as we go
        objective_score = objective(w, p, r, embedding)
        #accuracy_list.append(knn_accuracy(3, embedding, correct_groups, p))
        objective_list.append(objective_score)
        lambda_list.append(curr_lambda_list[0])

        #Keep me updated on progress
        print(f"Iteration #: {i}")
        print("Objective: ", objective_score)
        print(f"Lambda: {curr_lambda_list[0]}")
        #Code for 2D Graphs
        """
        if i%5 == 0 or i == 1:
            plt.scatter(embedding[:, 0], embedding[:, 1], c=correct_groups, cmap='rainbow')
            plt.savefig(f"Images/wine_embedding_step-{i}.png")
            plt.clf()

            
            ax = plt.axes(projection='3d')
            ax.locator_params(nbins=2)
            for j in range(0, len(embedding)):
                if correct_groups[j] == 0:
                    ax.plot(embedding[j, 0], embedding[j, 1], embedding[j, 2], marker="*", color='black')
                elif correct_groups[j] == 1:
                    ax.plot(embedding[j, 0], embedding[j, 1], embedding[j, 2], marker="x", color="red")
                elif correct_groups[j] == 2:
                    ax.plot(embedding[j, 0], embedding[j, 1], embedding[j, 2], marker="o", color="blue")
            plt.savefig(f"Images/embedding3D_step-{i}.png", dpi=1000)
            plt.clf()
            """

        #If we don't converge in 100 iterations - Stop
        if i >= 100:
            return embedding, objective_list, i, lambda_list, accuracy_list

    return embedding, objective_list, i, lambda_list, accuracy_list


def test_embedding(df, l_mu, x_mu, p_value, dimensions, initial_lambda, gaussian_constant=10):
    correct_groups = pd.Series.tolist(df.iloc[:, :1])
    correct_groups_flat = [item for sublist in correct_groups for item in sublist]
    number_groups = len(np.unique(correct_groups_flat))

    embedding, objective_list, iterations, lambda_list, accuracy_list = l_embedding(df, l_mu, x_mu, p_value, dimensions,
                                                                     initial_lambda, correct_groups_flat, gaussian_constant=gaussian_constant)

    clusters = KCluster(number_groups, embedding)
    return nmi_score(clusters, correct_groups_flat), cluster_acc(correct_groups_flat, clusters), purity_score(clusters, correct_groups_flat), adjusted_rand_score(correct_groups_flat,clusters)


def test_embedding_OML(df, l_mu, x_mu, p_value, dimensions, initial_lambda, prev_best_accuracy,
                             gaussian_constant=10):
    correct_groups = pd.Series.tolist(df.iloc[:, :1])
    correct_groups_flat = [item for sublist in correct_groups for item in sublist]

    embedding, objective_list, iterations, lambda_list, accuracy_list = l_embedding(df, l_mu, x_mu, p_value, dimensions,
                                                                         initial_lambda, correct_groups_flat,
                                                                         gaussian_constant)
    clusters = KCluster(3, embedding)
    print_results(embedding, iterations, objective_list, df, clusters, lambda_list, accuracy_list)

    return knn_OML(3, embedding, correct_groups_flat, p_value)


