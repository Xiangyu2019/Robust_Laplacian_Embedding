import imageio
import pandas as pd
from sklearn import preprocessing

import LPEmbedding
import imageio as img
import os

image_path = "./Data/ORL/"
all_images = []
image_classes = []

for file_name in os.listdir(image_path):
    if file_name.split('.')[1].lower() == "jpg":
        all_images.append(imageio.imread(image_path+file_name).flatten())
        image_classes.append(file_name.split(".")[0].split('_')[1])

df = pd.DataFrame(all_images)
df.dropna(axis=1, inplace=True)
d = preprocessing.normalize(df, axis=0)
scaled_df = pd.DataFrame(d)
scaled_df.insert(loc=0, column="Classes", value=image_classes)
sorted_df = scaled_df.sort_values(by='Classes')
print(sorted_df)

# Initial conditions
p_value = 1.1
initial_lambda = 1.4
dimensions = 2
l_mu = 2000
x_mu = 2000

print(LPEmbedding.test_embedding_OML(sorted_df, l_mu, x_mu, p_value, dimensions, initial_lambda, 0, gaussian_constant=10))


