import pandas as pd
import matplotlib.pyplot as plt

# Read data from DataFrame
df = pd.read_csv('obj_acc_1.csv')  # Replace 'data.csv' with your actual file name

# Set up the figure and axes
fig, ax1 = plt.subplots()
ax2 = ax1.twinx()

# Plot loss curves
ax1.plot(df['Iterations'], df['loss1'], color='red', label='Loss 1')
ax1.plot(df['Iterations'], df['loss2'], color='blue', label='Loss 2')
ax1.set_xlabel('Iterations')
ax1.set_ylabel('Loss')
ax1.tick_params(axis='y')
ax1.legend(loc='upper left')

# Plot accuracy curves
ax2.plot(df['Iterations'], df['acc1'], color='green', label='Accuracy 1')
ax2.plot(df['Iterations'], df['acc2'], color='orange', label='Accuracy 2')
ax2.set_ylabel('Accuracy')
ax2.tick_params(axis='y')
ax2.legend(loc='upper right')

# Set title and show the plot
plt.title('Loss and Accuracy Curves')
plt.show()
