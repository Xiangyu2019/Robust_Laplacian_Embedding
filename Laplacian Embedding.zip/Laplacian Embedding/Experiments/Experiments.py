import numpy as np
import pandas as pd
import LPEmbedding
from sklearn.decomposition import PCA
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.preprocessing import StandardScaler
from sklearn_pandas import DataFrameMapper
import AE
import torch
import matplotlib.pyplot as plt
import reduction
import Data_Prep



def grid_search():
    l_mus = [100, 1000]
    x_mus = [100, 1000]
    p_values = [1, 1.1, 1.5, 2]
    dimensions = 2
    initial_lambdas = [1]
    gaussian_constants = [1, 10, 100]
    scores_list = []
    iterations = 0
    for l_mu in l_mus:
        for x_mu in x_mus:
            for p_value in p_values:
                for initial_lambda in initial_lambdas:
                    for gaussian_constant in gaussian_constants:
                        for i in range(3):
                            try:
                                nmi_score, rand_score, purity = LPEmbedding.test_embedding(df, l_mu, x_mu, p_value,
                                                                                                   dimensions, initial_lambda,
                                                                                                   gaussian_constant)
                                scores_list.append(
                                    [l_mu, x_mu, p_value, initial_lambda, gaussian_constant, nmi_score, rand_score,
                                     purity])
                            except Exception as e:
                                print(e)
                                nmi_score, rand_score, purity = 0, 0, 0
                                scores_list.append(
                                    [l_mu, x_mu, p_value, initial_lambda, gaussian_constant, nmi_score, rand_score,
                                     purity])
                            iterations += 1
                            print(iterations)
                    np.savetxt("ionosphere_parameter_search.csv", scores_list, delimiter=',')


def RLE_Test(l_mu, x_mu, p_value, initial_lambda, dimensions):
    data = Data_Prep.data_input(prepro=True, noise=True)
    x, y_true = data.read_winedata()
    red = reduction.reduction(x, y_true)
    x_scaled = pd.DataFrame(red.X_F())
    x_original = x_scaled.values
    x_scaled.insert(0, "Labels", y_true)
    print(x_scaled)

    accuracy_list = []
    purity_list = []
    rand_list = []
    nmi_list = []

    for i in range(5):
        print(f"Iteration: {i}")
        nmi_score, ACC, purity, rand_score = LPEmbedding.test_embedding(x_scaled, l_mu, x_mu, p_value, dimensions,
                                                                             initial_lambda, gaussian_constant=10000)
        accuracy_list.append(ACC)
        purity_list.append(purity)
        rand_list.append(rand_score)
        nmi_list.append(nmi_score)


        print("\n")
        print(f"Highest Accuracy: {max(accuracy_list):.5f}")
        print(f"Average Accuracy: {np.mean(accuracy_list):.5f} +- {np.std(accuracy_list) :.5f}")
        print(f"Highest Purity: {max(purity_list):.5f}")
        print(f"Average Purity: {np.mean(purity_list):.5f} +- {np.std(purity_list):.5f}")
        print(f"Highest Rand Score: {max(rand_list):.5f}")
        print(f"Avg Rand Score: {np.mean(rand_list):.5f} +- {np.std(rand_list):.5f}")
        print(f"Highest NMI Score: {max(nmi_list):.5f}")
        print(f"Average NMI Score: {np.mean(nmi_list):.5f} +- {np.std(nmi_list):.5f}")

    return f"{np.mean(accuracy_list):.5f}"


def NN_Test():
    accuracy_list = []
    purity_list = []
    rand_list = []
    nmi_list = []
    data = Data_Prep.data_input(prepro=True, noise=True)
    x, y_true = data.read_uspsdata()
    red = reduction.reduction(x, y_true)
    for i in range(5):
        data, y_true = red.py_ae()
        y_pred = LPEmbedding.KCluster(len(np.unique(y_true)), data.T)
        nmi_list.append(LPEmbedding.nmi_score(y_true, y_pred))
        purity_list.append(LPEmbedding.purity_score(y_true, y_pred))
        rand_list.append(adjusted_rand_score(y_true, y_pred))
        accuracy_list.append((LPEmbedding.cluster_acc(y_true, y_pred)))

    print("\n")
    print(f"Highest Accuracy: {max(accuracy_list):.5f}")
    print(f"Average Accuracy: {np.mean(accuracy_list):.5f} +- {np.std(accuracy_list) :.5f}")
    print(f"Highest Purity: {max(purity_list):.5f}")
    print(f"Average Purity: {np.mean(purity_list):.5f} +- {np.std(purity_list):.5f}")
    print(f"Highest Rand Score: {max(rand_list):.5f}")
    print(f"Avg Rand Score: {np.mean(rand_list):.5f} +- {np.std(rand_list):.5f}")
    print(f"Highest NMI Score: {max(nmi_list):.5f}")
    print(f"Average NMI Score: {np.mean(nmi_list):.5f} +- {np.std(nmi_list):.5f}")


def Method_Test():
    accuracy_list = []
    purity_list = []
    rand_list = []
    nmi_list = []
    for i in range(50):
        data = Data_Prep.data_input(prepro=False, noise=True)
        x, y_true = data.read_uspsdata()
        red = reduction.reduction(x, y_true)
        data, y_true = red.sk_pca()
        data = data.T
        y_pred = LPEmbedding.KCluster(len(np.unique(y_true)), data)

        nmi_list.append(LPEmbedding.nmi_score(y_true, y_pred))
        purity_list.append(LPEmbedding.purity_score(y_true, y_pred))
        rand_list.append(adjusted_rand_score(y_true, y_pred))
        accuracy_list.append((LPEmbedding.cluster_acc(y_true, y_pred)))

        print("\n")
        print(f"Highest Accuracy: {max(accuracy_list):.5f}")
        print(f"Average Accuracy: {np.mean(accuracy_list):.5f} +- {np.std(accuracy_list) :.5f}")
        print(f"Highest Purity: {max(purity_list):.5f}")
        print(f"Average Purity: {np.mean(purity_list):.5f} +- {np.std(purity_list):.5f}")
        print(f"Highest Rand Score: {max(rand_list):.5f}")
        print(f"Avg Rand Score: {np.mean(rand_list):.5f} +- {np.std(rand_list):.5f}")
        print(f"Highest NMI Score: {max(nmi_list):.5f}")
        print(f"Average NMI Score: {np.mean(nmi_list):.5f} +- {np.std(nmi_list):.5f}")


def NCut_Test():
    accuracy_list = []
    purity_list = []
    rand_list = []
    nmi_list = []
    data = Data_Prep.data_input(prepro=False, noise=True)
    x, y_true = data.read_uspsdata()
    red = reduction.reduction(x, y_true)
    x_scaled = pd.DataFrame(red.X_F())
    x_scaled.insert(0, "Labels", y_true)
    print(x_scaled)
    w = LPEmbedding.create_w_gaussian_optimized(x_scaled.values, 100)
    for i in range(50):

        print(f"NCUT Test, Iteration: {i}")

        red = reduction.reduction(x, y_true)
        y_pred, y_true = red.NCut(affinity=w)


        nmi_list.append(LPEmbedding.nmi_score(y_true, y_pred))
        purity_list.append(LPEmbedding.purity_score(y_true, y_pred))
        rand_list.append(adjusted_rand_score(y_true, y_pred))
        accuracy_list.append((LPEmbedding.cluster_acc(y_true, y_pred)))

        print("\n")
        print(f"Highest Accuracy: {max(accuracy_list):.5f}")
        print(f"Average Accuracy: {np.mean(accuracy_list):.5f} +- {np.std(accuracy_list) :.5f}")
        print(f"Highest Purity: {max(purity_list):.5f}")
        print(f"Average Purity: {np.mean(purity_list):.5f} +- {np.std(purity_list):.5f}")
        print(f"Highest Rand Score: {max(rand_list):.5f}")
        print(f"Avg Rand Score: {np.mean(rand_list):.5f} +- {np.std(rand_list):.5f}")
        print(f"Highest NMI Score: {max(nmi_list):.5f}")
        print(f"Average NMI Score: {np.mean(nmi_list):.5f} +- {np.std(nmi_list):.5f}")


def PNLE_test():
    accuracy_list = []
    purity_list = []
    rand_list = []
    nmi_list = []
    data = Data_Prep.data_input(prepro=False, noise=False)
    x, y_true = data.read_winedata()
    red = reduction.reduction(x, y_true, n=3)
    x_scaled = pd.DataFrame(red.X_F())
    x_scaled.insert(0, "Labels", y_true)
    w = LPEmbedding.create_w_gaussian(x_scaled, 1)
    for i in range(1):
        print(f"PNLE Test, Iteration: {i}")

        embedding = red.PNLE(w,1.4,10)
        print(embedding)
        #y_pred = LPEmbedding.KCluster(len(np.unique(y_true)), embedding)
        y_pred = embedding.argmax(axis=1)

        nmi_list.append(LPEmbedding.nmi_score(y_true, y_pred))
        purity_list.append(LPEmbedding.purity_score(y_true, y_pred))
        rand_list.append(adjusted_rand_score(y_true, y_pred))
        accuracy_list.append((LPEmbedding.cluster_acc(y_true, y_pred)))

        print("\n")
        print(f"Highest Accuracy: {max(accuracy_list):.5f}")
        print(f"Average Accuracy: {np.mean(accuracy_list):.5f} +- {np.std(accuracy_list) :.5f}")
        print(f"Highest Purity: {max(purity_list):.5f}")
        print(f"Average Purity: {np.mean(purity_list):.5f} +- {np.std(purity_list):.5f}")
        print(f"Highest Rand Score: {max(rand_list):.5f}")
        print(f"Avg Rand Score: {np.mean(rand_list):.5f} +- {np.std(rand_list):.5f}")
        print(f"Highest NMI Score: {max(nmi_list):.5f}")
        print(f"Average NMI Score: {np.mean(nmi_list):.5f} +- {np.std(nmi_list):.5f}")


def p_value_test():
    p_list = [i/10 for i in range(10,20,3)]
    l_list = [i for i in range(1000,10000,500)]
    big_list = []
    for i in p_list:
        for j in l_list:
            try:
                big_list.append([i, RLE_Test(j, j, i, 1, 2)])
            except:
                big_list.append([i, 0])

    print(big_list)


#RLE_Test(2000, 2000, 1.3, 1, 2)
#parameter_test(2000, 2000, 1.5, 1, 2)
#grid_search()
#NCut_Test()
#Method_Test()
#NN_Test()
PNLE_test()
#p_value_test()