import os
import matplotlib
import matplotlib as mpl
from scipy.interpolate import griddata
import skimage
import numpy as np
import sys
from scipy.interpolate import RectBivariateSpline
import matplotlib.tri as mtri
import matplotlib.cm as cm
from mpl_toolkits.mplot3d import Axes3D
from sklearn.preprocessing import MinMaxScaler
from mpl_toolkits import mplot3d
import matplotlib.pylab as plt
import pandas as pd
import random
import cv2
import copy
import struct
import h5py
from sklearn import datasets
from sklearn import preprocessing
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.tri as tri
from matplotlib.colors import Normalize

def conver_plot():
    df = pd.read_excel('convergence.xlsx')
    fig = plt.figure()
    ax1 = fig.add_subplot(1,1,1)
    ax1.plot(df['B_0'],df['B_0_Y'],label="Barron $\gamma=0$")
    ax1.plot(df['B_2'],df['B_2_Y'],label="Barron $\gamma=2$")
    ax1.plot(df['B_INF'],df['B_INF_Y'],label="Barron $\gamma=-\infty$")
    ax1.plot(df['B_OTHER'],df['B_OTHER_Y'],label="Barron $\gamma=$other")
    ax1.plot(df['CAUCHY'],df['CAUCHY_Y'],label="Cauchy loss")
    ax1.plot(df['HUBER'],df['HUBER_Y'],label="Huber loss")
    ax1.plot(df['LOG'], df['LOG_Y'], label="Log-cosh loss")
    ax1.plot(df['NIE'],df['NIE_Y'],label="Nie Adpt. loss")
    ax1.plot(df['L2'],df['L2_Y'],label="$\ell_{2}$-norm loss")
    ax1.plot(df['LP'],df['LP_Y'],label="$\ell_{p}$-norm loss")
    # ax1.legend(fontsize=14, loc=(0.57,0.25))
    ax1.legend(fontsize=13)
    plt.xlabel('Iteration number', fontsize=15)
    plt.ylabel('Reconstruction error', fontsize=15)
    plt.xlim(0,160)
    plt.ylim(2.5,8)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    plt.tight_layout()
    plt.savefig('convergence.pdf')
    plt.show()

class noise:
    def __init__(self, image):
        self.image = image

    #  Gaussian Noise
    def Gaussian(self,var):
        noisy_gau_1 = skimage.util.random_noise(self.image, mode='gaussian', var=var)
        # noisy_gau_5 = skimage.util.random_noise(self.image, mode='gaussian', var=0.05)
        return noisy_gau_1

    # Salt&Pepper noise 1
    def s_p (self):
        noisy_sp = skimage.util.random_noise(self.image, mode='s&p')
        # plt.imshow(noisy_sp, cmap='gray')
        # plt.axis('off')
        # plt.savefig('s_p.pdf', bbox_inches='tight')
        # plt.show()
        return noisy_sp

    # Salt&Pepper noise 2 (add diffent amount of noise into data)
    def s_p_amount (self,amount):
        img_x, img_y = self.image.shape
        s_vs_p = 0.5
        out = np.copy(self.image)
        # Salt mode
        num_salt = np.ceil(amount * self.image.size * s_vs_p)
        coords = [np.random.randint(0, i - 1, int(num_salt))
                  for i in self.image.shape]
        out[tuple(coords)] = 255
        # Pepper mode
        num_pepper = np.ceil(amount * self.image.size * (1. - s_vs_p))
        coords = [np.random.randint(0, i - 1, int(num_pepper))
                  for i in self.image.shape]
        out[tuple(coords)] = 0
        return out

    # Block noise
    def box (self, length = 50, width= 60):
        img = copy.deepcopy(self.image)
        img_x, img_y = img.shape
        seed = [0,255]
        box = []
        for i in range(length*width):
            random_num = random.choice(seed)
            box.append(random_num)
        box = np.array(box).reshape(length,width)
        x= np.random.randint(low=0, high=img_x-length, size=1)[0]
        y= np.random.randint(low=0, high=img_y-width, size=1)[0]
        img[x:x+length, y:y+width] = box
        return img

    def box_black (self, length = 50, width= 60):
        img = copy.deepcopy(self.image)
        img_x, img_y = img.shape
        seed = [0,255]
        box = np.full((length, width), 100)
        # for i in range(length*width):
        #     random_num = random.choice(seed)
        #     box.append(random_num)
        # box = np.array(box).reshape(length,width)
        x= np.random.randint(low=0, high=img_x-length, size=1)[0]
        y= np.random.randint(low=0, high=img_y-width, size=1)[0]
        img[x:x+length, y:y+width] = box
        return img

    def box_white (self, length = 50, width= 60):
        img = copy.deepcopy(self.image)
        img_x, img_y = img.shape
        seed = [0,255]
        box = np.full((length, width), 255)
        # for i in range(length*width):
        #     random_num = random.choice(seed)
        #     box.append(random_num)
        # box = np.array(box).reshape(length,width)
        x= np.random.randint(low=0, high=img_x-length, size=1)[0]
        y= np.random.randint(low=0, high=img_y-width, size=1)[0]
        img[x:x+length, y:y+width] = box
        return img

    def box_vir (self, length = 50, width= 60):
        img_vir = cv2.imread('virus.jpg')
        img_vir_gray = cv2.cvtColor(img_vir, cv2.COLOR_BGR2GRAY)
        img = copy.deepcopy(self.image)
        img_x, img_y = img.shape
        seed = [0,255]
        # box = []
        # for i in range(length*width):
        #     random_num = random.choice(seed)
        #     box.append(random_num)
        # box = np.array(box).reshape(length,width)
        box = cv2.resize(img_vir_gray,(width,length))
        x= np.random.randint(low=0, high=img_x-length, size=1)[0]
        y= np.random.randint(low=0, high=img_y-width, size=1)[0]
        img[x:x+length, y:y+width] = box
        return img

def read_coil20data():
    path = 'D:\Research\TKDD_Kai\dataset\COIL20\coil-20-proc'
    obj_num = 20
    obj_face_num = 72
    raw_img = []
    data_set = []
    data_set_label = []
    for i in range(1, obj_num + 1):
        if i in [4,8,12,14]:
            obj_path = path + '/' + 'obj' + str(i) + '__'
            for j in range(0, obj_face_num):
                if j == 1:
                    img = cv2.imread(obj_path + str(j) + '.png')
                    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    height, width = img_gray.shape
                    img_gray0 = img_gray.reshape(height * width)
                    # img_gray1 = noise(img_gray).Gaussian(var=0.05).reshape(height * width)
                    # img_gray2 = noise(img_gray).Gaussian(var=0.10).reshape(height * width)
                    # img_gray3 = noise(img_gray).Gaussian(var=0.20).reshape(height * width)
                    # img_gray4 = noise(img_gray).Gaussian(var=0.30).reshape(height * width)
                    # img_gray = noise(img_gray).s_p_amount(0.4)
                    # img_gray = cv2.resize(img_gray, (32, 32))

                    img_gray1 = noise(img_gray).box(length = 50, width= 60).reshape(height * width)
                    img_gray2 = noise(img_gray).box_vir(length=50, width=60).reshape(height * width)
                    img_gray3 = noise(img_gray).box_black(length=50, width=60).reshape(height * width)
                    img_gray4 = noise(img_gray).box_white(length=50, width=60).reshape(height * width)

                    # img_col = img_gray.reshape(height * width)
                    raw_img.append([img_gray0,img_gray1,img_gray2,img_gray3,img_gray4])
                    # raw_img.append(img_gray3)
    raw_img = np.array(raw_img)
    return raw_img

def read_attdata():
    face_path = "D:/Research/TKDD_Kai/dataset/ATT"
    person_num = 40
    person_face_num = 10
    raw_img = []
    data_set = []
    data_set_label = []
    for i in range(1,person_num+1):
        if i in [4,8,12,20]:
            person_path = face_path+'/s'+str(i)
            for j in range(1,person_face_num+1):
                if j == 1:
                    img = cv2.imread(person_path + '/' + str(j) + '.pgm')
                    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    height, width = img_gray.shape
                    img_gray0 = img_gray.reshape(height * width)
                    # img_gray1 = noise(img_gray).box(length = 50, width= 60).reshape(height * width)
                    # img_gray2 = noise(img_gray).box_vir(length=50, width=60).reshape(height * width)
                    # img_gray3 = noise(img_gray).box_black(length=50, width=60).reshape(height * width)
                    # img_gray4 = noise(img_gray).box_white(length=50, width=60).reshape(height * width)
                    img_gray1 = noise(img_gray).Gaussian(var=0.02).reshape(height * width)
                    img_gray2 = noise(img_gray).Gaussian(var=0.05).reshape(height * width)
                    img_gray3 = noise(img_gray).Gaussian(var=0.08).reshape(height * width)
                    img_gray4 = noise(img_gray).Gaussian(var=0.10).reshape(height * width)

                    raw_img.append([img_gray0,img_gray1,img_gray2,img_gray3,img_gray4])

    X = np.array(raw_img)

    return X

def plot_gallery(images, n_col=5, n_row=4, cmap=plt.cm.gray):
    plt.figure(figsize=(2. * n_col, 2.26 * n_row))
    # plt.suptitle(title, size=16)
    image_shape =(112,92)
    img_n,noi,_ = images.shape
    sum = 0
    for i in range(img_n):
        for j in range(noi):
            sum += 1
            plt.subplot(n_row, n_col, sum)
            vmax = max(images[i][j].max(), -images[i][j].min())
            # plt.imshow(comp.reshape(image_shape), cmap=cmap,
            #            interpolation='nearest',
            #            vmin=-vmax, vmax=vmax)
            plt.imshow(images[i][j].reshape(image_shape), cmap=cmap)
            plt.xticks(())
            plt.yticks(())
    # sum = 0
    # for i, comp in enumerate(images):
        # if (i%2) == 0:
        #     sum = sum +1
        #     plt.subplot(n_row, n_col, sum)
        #     vmax = max(comp.max(), -comp.min())
        #     # plt.imshow(comp.reshape(image_shape), cmap=cmap,
        #     #            interpolation='nearest',
        #     #            vmin=-vmax, vmax=vmax)
        #     plt.imshow(comp.reshape(image_shape), cmap=cmap)
        #     plt.xticks(())
        #     plt.yticks(())
    plt.text(0.04, 0.0, "original", size=25,transform=plt.gcf().transFigure)
    plt.text(0.23, 0.0, "$\sigma^{2}$=0.02", size=25, transform=plt.gcf().transFigure)
    plt.text(0.43, 0.0, "$\sigma^{2}$=0.05", size=25, transform=plt.gcf().transFigure)
    plt.text(0.63, 0.0, "$\sigma^{2}$=0.08", size=25, transform=plt.gcf().transFigure)
    plt.text(0.83, 0.0, "$\sigma^{2}$=0.10", size=25, transform=plt.gcf().transFigure)

    # plt.text(0.04, 0.0, "original", size=25,transform=plt.gcf().transFigure)
    # plt.text(0.20, 0.0, "black&white", size=25, transform=plt.gcf().transFigure)
    # plt.text(0.45, 0.0, "virus", size=25, transform=plt.gcf().transFigure)
    # plt.text(0.64, 0.0, "grey", size=25, transform=plt.gcf().transFigure)
    # plt.text(0.84, 0.0, "white", size=25, transform=plt.gcf().transFigure)
    plt.subplots_adjust(0.01, 0.05, 0.99, 0.93, 0.04, 0.)

    plt.savefig("att.pdf", bbox_inches='tight')
    plt.show

# Result: acc vs. block noise type
def plot_coil_block():
    df = pd.read_excel('COIL_BLOCK.xlsx', index_col='VAR')
    ticks_text = df.index.to_numpy()
    ticks = np.array([1,2,3,4,5])
    error = df.iloc[:,1::2].to_numpy()
    data = df.iloc[:,::2].to_numpy()
    model_name = df.columns.tolist()[0::2]
    marker = ['o','X','^','s','D','H','p']
    plt.figure()
    for i in range(data.shape[1]):
        value = data[:,i]
        val_e = error[:,i]
        if i < 4:
            plt.errorbar(ticks - 0.15*i, value, val_e, elinewidth=1.5, capsize=5, fmt=marker[i],label=model_name[i])
        elif i == 4:
            plt.errorbar(ticks, value, val_e, elinewidth=1.5, capsize=5, fmt=marker[i],label=model_name[i])
        else:
            i = i-4
            plt.errorbar(ticks + 0.15 * i, value, val_e, elinewidth=1.5, capsize=5, fmt=marker[i+4],label=model_name[i+4])
    # plt.vlines(x=1, ls='--',c='grey')
    plt.xticks(ticks, ticks_text)
    plt.axvline(x=1.44,linestyle='--',c='grey')
    plt.axvline(x=2.44,linestyle='--',c='grey')
    plt.axvline(x=3.44,linestyle='--',c='grey')
    plt.axvline(x=4.44,linestyle='--',c='grey')
    plt.xlabel('Block noise type', fontsize=15)
    plt.ylabel('Accuracy score', fontsize=15)
    # plt.xlim(0,160)
    plt.ylim(0.2,0.9)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    # plt.legend(fontsize=13)
    plt.legend(bbox_to_anchor=(0,1.02,1,0.2), loc="lower left",
                mode="expand", borderaxespad=0.2, handletextpad=0.1, ncol=4,fontsize=12)
    plt.tight_layout()
    # plt.show()
    plt.savefig("COIL_BLOCK.pdf", bbox_inches='tight')

# result (gaussian noise): acc vs. noise_variance
def plot_gauvar():
    df = pd.read_excel('FERET_VAR.xlsx', index_col='VAR')
    ticks_text = df.index.to_numpy()
    data = df.iloc[:, :].to_numpy()
    model_name = df.columns.tolist()[0::1]
    marker = ['o', 'X', '^', 's', 'D', 'H', 'p']
    plt.figure()
    for i in range(data.shape[1]):
        print(i)
        plt.plot(ticks_text, data[:,i], marker =marker[i],label=model_name[i])

    plt.xlabel('Variance value', fontsize=15)
    plt.ylabel('Accuracy score', fontsize=15)
    plt.xlim(min(ticks_text),max(ticks_text))
    plt.ylim(0.0, 0.8)
    xt = [0.02,0.04,0.06,0.08,0.1,0.12,0.14,0.16,0.18,0.20]
    #
    plt.xticks(xt,fontsize=14)
    plt.yticks(fontsize=14)
    plt.legend(fontsize=13)
    # plt.legend(bbox_to_anchor=(0, 1.02, 1, 0.2), loc="lower left",
    #            mode="expand", borderaxespad=0.2, handletextpad=0.1, ncol=4, fontsize=12)
    plt.tight_layout()
    # plt.show()
    plt.savefig("FERET_VAR.pdf", bbox_inches='tight')

# result: acc vs. dimensionality
def plot_dim():
    df = pd.read_excel('DIM_COIL20.xlsx', index_col='DIM')
    ticks_text = df.index.to_numpy()
    data = df.iloc[:, :].to_numpy()
    model_name = df.columns.tolist()[0::1]
    marker = ['o', 'X', '^', 's', 'D', 'H', 'p']
    color = ['black','red','coral','orange','green','blue','darkviolet']
    plt.figure()
    for i in range(data.shape[1]):
        if i <=6:
            plt.plot(ticks_text, data[:, i], color = color[i], marker =marker[i],label=model_name[i])
        if i >= 7:
            plt.plot(ticks_text, data[:, i], linestyle='dashed', color = color[i-7], marker=marker[i-7],label=f'{model_name[i-7]}(Noise)')

    plt.xlabel('Number of dimensions', fontsize=15)
    plt.ylabel('Accuracy score', fontsize=15)
    # plt.xlim(min(ticks_text),max(ticks_text))
    plt.xlim(5.0, 100)
    plt.ylim(0.0, 0.9)
    xt = [5,20,40,60,80,100]
    #
    plt.xticks(xt,fontsize=14)
    plt.yticks(fontsize=14)
    plt.legend(borderaxespad=0.2,handletextpad=0.1,ncol=2,fontsize=10)
    # plt.legend(bbox_to_anchor=(0, 1.02, 1, 0.2), loc="lower left",
    #            mode="expand", borderaxespad=0.2, handletextpad=0.1, ncol=4, fontsize=12)
    plt.tight_layout()
    # plt.show()
    plt.savefig("DIM_COIL20.pdf", bbox_inches='tight')

# result: acc vs. parameter selections
def plot_polar():

    df = pd.read_excel('MNIST_PAR.xlsx')
    x = np.log10(df.loc[:, 'alpha1'].to_numpy())
    y = np.log10(df.loc[:, 'alpha2'].to_numpy())
    z = np.log10(df.loc[:, 'alpha4'].to_numpy())
    c = df.loc[:, 'acc'].to_numpy()
    df1 = df.loc[:,:'alpha4']
    print(df1[df1.duplicated()])
    # input('===')
    for i in range(len(c)):
        if c[i] < 0.6:
            c[i] = c[i] + 0.01
    do_random_pt_example = True
    index_x = 0
    index_y = 1
    index_z = 2
    index_c = 3
    list_name_variables = [r'$log(\alpha_{1})$', r'$log(\alpha_{2})$', r'$log(\alpha_{4})$', 'Accuracy score']
    cmap = mpl.cm.hsv

    # We create triangles that join 3 pt at a time and where their colors will be
    # determined by the values ​​of their 4th dimension. Each triangle contains 3
    # indexes corresponding to the line number of the points to be grouped.
    # Therefore, different methods can be used to define the value that
    # will represent the 3 grouped points and I put some examples.
    triangles = mtri.Triangulation(x, y).triangles

    choice_calcuation_colors = 1
    if choice_calcuation_colors == 1:  # Mean of the "c" values of the 3 pt of the triangle
        colors = np.mean([c[triangles[:, 0]], c[triangles[:, 1]], c[triangles[:, 2]]], axis=0)
    elif choice_calcuation_colors == 2:  # Mediane of the "c" values of the 3 pt of the triangle
        colors = np.median([c[triangles[:, 0]], c[triangles[:, 1]], c[triangles[:, 2]]], axis=0)
    elif choice_calcuation_colors == 3:  # Max of the "c" values of the 3 pt of the triangle
        colors = np.max([c[triangles[:, 0]], c[triangles[:, 1]], c[triangles[:, 2]]], axis=0)
    # end
    # ----------
    # Displays the 4D graphic.
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    triang = mtri.Triangulation(x, y, triangles)
    surf = ax.plot_trisurf(triang, z, cmap=cmap, shade=False, linewidth=0.2,vmin=0.55,vmax=0.65)
    surf.set_array(colors)
    # surf.autoscale()

    # # Add a color bar with a title to explain which variable is represented by the color.

    cbar = fig.colorbar(surf,shrink=0.6,aspect=8.25,ticks=[0.55,0.60,0.65])
    cbar.ax.get_yaxis().labelpad = 20
    cbar.ax.tick_params(labelsize=12)
    cbar.ax.set_ylabel(list_name_variables[index_c],fontsize=15, rotation=270)


    # Add titles to the axes and a title in the figure.
    # ax.set_xscale("log")
    t_label = [r'$10^{-3}$', r'$10^{-2}$', r'$10^{-1}$', r'$10^{-0}$', r'$10^{-1}$',r'$10^{-2}$',r'$10^{-3}$']
    ax.set_xticks(np.arange(-3,4,1))
    ax.set_yticks(np.arange(-3,4,1))
    ax.set_zticks(np.arange(-3,4,1))
    # ax.set_xticklabels(t_label)
    # ax.set_yticklabels(t_label)
    # ax.set_zticklabels(t_label)

    ax.set_xlabel(list_name_variables[index_x], fontsize=15)
    ax.set_ylabel(list_name_variables[index_y], fontsize=15)
    ax.set_zlabel(list_name_variables[index_z], fontsize=15)
    ax.tick_params(labelsize=14)

    ax.view_init(azim=-109, elev=33)
    ax.set_proj_type('ortho')

    ax.xaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
    ax.yaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
    ax.zaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
    # ax.grid(b=False)

    # plt.title('%s in function of %s, %s and %s' % (
    # list_name_variables[index_c], list_name_variables[index_x], list_name_variables[index_y],
    # list_name_variables[index_z]))
    plt.tight_layout()
    plt.savefig("MNIST_PAR.pdf", bbox_inches='tight')
    plt.show()



if __name__ == '__main__':
    np.set_printoptions(threshold=sys.maxsize)
    img = read_attdata()
    plot_gallery(img)


