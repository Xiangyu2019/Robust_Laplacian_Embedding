import numpy as np
import pandas as pd
import cv2
import os
import struct
import h5py
import sklearn.datasets
from sklearn import datasets
from sklearn import preprocessing
import h5py
from functools import reduce
from tensorflow.keras.datasets import mnist
import os
#X_c = (n_class[c], ni_samples[n_i], n_features[d])
class data_input:
    def __init__(self, prepro, noise):
        self.prepro = prepro
        self.noise = noise
    # MinMaxScaler Preprocessing and Gaussian noise
    def proces_data(self, X):
        if self.prepro == True:
            #X = preprocessing.MinMaxScaler().fit_transform(X)
            X = preprocessing.StandardScaler().fit_transform(X)

        if self.noise == True:
            X = X + np.random.normal(0.0, 2, X.shape)
        return X
    # iris data (n_samples=150,n_features=4)
    def read_irisdata(self):
        iris = datasets.load_iris()
        df = pd.DataFrame(data=np.c_[iris['data'], iris['target']],
                          columns=iris['feature_names'] + ['target'])
        df['species'] = pd.Categorical.from_codes(iris.target, iris.target_names)
        df.columns = ['s_length', 's_width', 'p_length', 'p_width', 'target', 'species']
        y = df['target'].unique().astype(int)
        X_c = []
        label = []
        for i in y:
            Xi = self.proces_data(df[df['target'] == i].iloc[:, 0:4].to_numpy())
            X_c.append(Xi)
            Yi = df[df['target'] == i].loc[:, 'target'].to_numpy()
            label.append(Yi)
        X_c = np.array(X_c)
        label = np.array(label).flatten()
        return X_c, label

    # Wine data (n_samples=178,n_features=13)
    def read_winedata(self):
        wine = datasets.load_wine()
        data = wine.data
        label = wine.target
        X_c = []
        for i in np.unique(label):
            indices = np.where(label == i)[0]
            Xi = data[indices]
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c,dtype=object)
        return X_c, label
    # Cancer data (n_samples=569,n_features=30)
    def read_cancerdata(self):
        cancer = datasets.load_breast_cancer()
        data = cancer.data
        label = cancer.target
        X_c = []
        for i in np.unique(label):
            indices = np.where(label == i)[0]
            Xi = data[indices]
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c)
        return X_c, label
    #ATT data (n_samples=400,n_features=4096)
    def read_attdata(self):
        att = datasets.fetch_olivetti_faces()
        data = att.data
        label = att.target
        X_c = []
        for i in np.unique(label):
            indices = np.where(label == i)[0]
            Xi = data[indices]
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c)
        return X_c, label
    # mnist data (n_samples=60000,n_features=784)
    def read_mnistdata(self):
        (X_tr, Y_tr), (X_test, Y_test) = mnist.load_data()
        X_tr = X_tr.reshape(X_tr.shape[0], reduce(lambda a, b: a * b, X_tr.shape[1:]))
        return X_tr, Y_tr
    #usps data (n_samples=7291,n_features=256)
    def read_uspsdata(self, path="Data/usps.h5", data_key="data", target_key="target", flatten=True):
        with h5py.File(path, 'r') as hf:
            train = hf.get('train')
            X_tr = train.get(data_key)[:]
            y_tr = train.get(target_key)[:]
            test = hf.get('test')
            X_te = test.get(data_key)[:]
            y_te = test.get(target_key)[:]
            if flatten:
                X_tr = X_tr.reshape(X_tr.shape[0], reduce(lambda a, b: a * b, X_tr.shape[1:]))
                X_te = X_te.reshape(X_te.shape[0], reduce(lambda a, b: a * b, X_te.shape[1:]))
        return self.proces_data(X_tr), y_tr
    #ionosphere_data (n_samples=351,n_features=34)
    def read_ionospheredata(self):
        path = 'Data/ionosphere_raw.data'
        raw_dataset = pd.read_csv(path, delimiter=',', header=None)
        le = preprocessing.LabelEncoder()
        le.fit(raw_dataset.iloc[:, -1])
        raw_dataset['int_label'] = le.transform(raw_dataset.iloc[:, -1])
        X = []
        Y = []
        for i in raw_dataset.index:
            X.append(raw_dataset.iloc[i, :-2])
            Y.append(raw_dataset.iloc[i, -1])
        X = np.array(X)
        Y = np.array(Y)
        X_c = []
        for i in np.unique(Y):
            indices = np.where(Y == i)[0]
            Xi = X[indices]
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c,dtype=object)
        return X_c, Y
    #Coil20_data (n_samples=1440, n_features=128 x 128 = 16384 grayscale images) (20 objects with 72 poses each), with 16,384 features (the value of the 128 x 128 pixels).
    def read_coil20data(self):
        path = 'Data/coil-20-proc'
        obj_num = 20
        obj_face_num = 72
        raw_img = []
        data_set = []
        data_set_label = []
        for i in range(1, obj_num+1):
            obj_path = path + '/' + 'obj' +str(i) + '__'
            for j in range(0, obj_face_num):
                img = cv2.imread(obj_path + str(j) + '.png')
                # if j == 1:
                #     raw_img.append(img)
                img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                img_gray = cv2.resize(img_gray,(32,32))
                height, width = img_gray.shape
                img_col = img_gray.reshape(height * width)
                data_set.append(img_col)
                data_set_label.append(i-1)
        X = np.array(data_set)
        Y = np.array(data_set_label)
        X_c = []
        for i in np.unique(Y):
            indices = np.where(Y == i)[0]
            Xi = X[indices]
            Xi = Xi.astype(np.float32)
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c,dtype=np.float32)
        return X_c, Y

    def read_glassdata(self):
        path = 'Data/glass_raw.data'
        raw_dataset = pd.read_csv(path, delimiter=',', header=None)
        le = preprocessing.LabelEncoder()
        le.fit(raw_dataset.iloc[:, -1])
        raw_dataset['int_label'] = le.transform(raw_dataset.iloc[:, -1])
        X = []
        Y = []
        for i in raw_dataset.index:
            X.append(raw_dataset.iloc[i, :-2])
            Y.append(raw_dataset.iloc[i, -1])
        X = np.array(X)
        Y = np.array(Y)
        X_c = []
        for i in np.unique(Y):
            indices = np.where(Y == i)[0]
            Xi = X[indices]
            Xi = self.proces_data(Xi)
            X_c.append(Xi)
        X_c = np.array(X_c,dtype=object)
        return X_c, Y

    def random_data(self, samples, features, centers, cluster_std, random_state):
        dataset, classes = sklearn.datasets.make_blobs(n_samples=samples, n_features=features, centers=centers, cluster_std=cluster_std, random_state=random_state)
        return dataset, classes