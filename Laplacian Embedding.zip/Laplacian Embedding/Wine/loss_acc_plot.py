import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline

# Read data from CSV file
df = pd.read_csv('obj_acc_1.csv')

# Extract data columns
iterations = df['Iterations']
loss1 = df['loss1']
loss2 = df['loss2']
acc1 = df['acc1']
acc2 = df['acc2']

# Check and remove inf and nan values
valid_indices = np.isfinite(iterations) & np.isfinite(loss1) & np.isfinite(loss2) & np.isfinite(acc1) & np.isfinite(acc2)
iterations = iterations[valid_indices]
loss1 = loss1[valid_indices]
loss2 = loss2[valid_indices]
acc1 = acc1[valid_indices]
acc2 = acc2[valid_indices]

# Set up the figure and axes
fig, ax1 = plt.subplots()
ax2 = ax1.twinx()

# Generate smooth curves
x_smooth = np.linspace(iterations.min(), iterations.max(), 300)
spl1 = make_interp_spline(iterations, loss1)
spl2 = make_interp_spline(iterations, loss2)
spl3 = make_interp_spline(iterations, acc1)
spl4 = make_interp_spline(iterations, acc2)
loss1_smooth = spl1(x_smooth)
loss2_smooth = spl2(x_smooth)
acc1_smooth = spl3(x_smooth)
acc2_smooth = spl4(x_smooth)

# Plot loss curves
ax1.plot(x_smooth, loss1_smooth, color='green', linestyle='-', linewidth=2, label='Loss(Ours)')
ax1.plot(x_smooth, loss2_smooth, color='blue', linestyle='-', linewidth=2, label='Loss(PGD)')
ax1.set_xlabel('Iterations', fontsize=14)
ax1.set_ylabel('Loss', fontsize=14)
ax1.tick_params(axis='both', which='major', labelsize=12)
ax1.set_xlim(0, iterations.max())  # Set x-axis limits starting from 0
ax1.set_ylim(0, max(loss1.max(), loss2.max()))  # Set y-axis limits starting from 0

# Plot accuracy curves
ax2.plot(x_smooth, acc1_smooth, color='green', linestyle='--', linewidth=2, label='Acc(Ours)')
ax2.plot(x_smooth, acc2_smooth, color='blue', linestyle='--', linewidth=2, label='Acc(PGD)')
ax2.set_ylabel('Accuracy', fontsize=14)
ax2.tick_params(axis='y', labelcolor='red', labelsize=12)  # Change the color and font size of the right y-axis ticks
ax2.set_ylim(0, max(acc1.max(), acc2.max()))  # Set y-axis limits starting from 0

# Move the legend box closer to the figure and display all items in a single line
lines, labels = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
legend= ax1.legend(lines + lines2, labels + labels2, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=4, fontsize=12, frameon=False,handlelength=1.5)

# # Bold the legend font
# for text in legend.get_texts():
#     text.set_fontweight('bold')

# Add scale unit to the top left y-axis
ax1.text(-0.07, 1.00, r'$\times 10^2$', transform=ax1.transAxes, fontsize=14)

# Set title and show the plot
plt.title('Loss and Accuracy Curves (Olivetti)', fontsize=14)
plt.tight_layout()

# Save the plot as a PDF file and crop out the surrounding white margins
plt.savefig('plot.pdf', format='pdf', bbox_inches='tight', pad_inches=0)

plt.show()
