# import pandas as pd
# import numpy as np
#
# # Set the range and number of random numbers
# start_value = 0.66
# end_value = 0.71
# num_numbers = 170
#
# # Generate a sequence of decreasing numbers
# decreasing_numbers = np.linspace(start_value, end_value, num_numbers)
#
# # Add random fluctuations to the numbers
# fluctuations = np.random.uniform(low=-1, high=1, size=num_numbers)
# random_numbers = decreasing_numbers + fluctuations
#
# # Create a DataFrame from the random numbers
# df = pd.DataFrame({'Random Numbers': random_numbers})
#
# # Save the DataFrame to a CSV file
# df.to_csv('random_numbers0.csv', index=False)

import pandas as pd
import numpy as np

# Set the range and number of values
start_value = 0.72
end_value = 0.78
num_values = 72

# Generate a sequence of smoothly increasing numbers
x = np.linspace(0, 1, num_values)
smooth_numbers = start_value + (end_value - start_value) * (1 / (1 + np.exp(-10*(x-0.5))))

# Create a DataFrame from the smooth numbers
df = pd.DataFrame({'Smooth Numbers': smooth_numbers})

# Save the DataFrame to a CSV file
df.to_csv('smooth_numbers.csv', index=False)

# #
import pandas as pd
import numpy as np

# # Set the range and number of values
# num_values = 157

# # Generate random values between 0.1 and 0.9
# values = np.random.uniform(0.70, 0.77, num_values)
#
# # Add random fluctuations
# fluctuations = np.random.normal(0, 0.02, num_values)  # Adjust the mean and standard deviation as desired
# values_with_fluctuations = values + fluctuations
#
# # Sort the values in increasing order
# values_with_fluctuations.sort()
#
# # Create a DataFrame from the values with fluctuations
# df = pd.DataFrame({'Values with Fluctuations': values_with_fluctuations})
#
# # Save the DataFrame to a CSV file
# df.to_csv('values_with_fluctuations.csv', index=False)




